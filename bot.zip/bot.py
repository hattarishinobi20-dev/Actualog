import csv
import hashlib
import html
import inspect
import json
import os
import sqlite3
import sys
import threading
import time
from pathlib import Path

import telebot
from telebot import types


BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
CONFIG = {}
if CONFIG_PATH.exists():
    try:
        CONFIG = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        CONFIG = {}

BOT_TOKEN = os.getenv("BOT_TOKEN") or CONFIG.get("BOT_TOKEN", "")
ADMIN_IDS_RAW = os.getenv("ADMIN_IDS") or CONFIG.get("ADMIN_IDS", [])
if isinstance(ADMIN_IDS_RAW, str):
    ADMIN_IDS = {int(x.strip()) for x in ADMIN_IDS_RAW.split(",") if x.strip().lstrip("-").isdigit()}
else:
    ADMIN_IDS = {int(x) for x in ADMIN_IDS_RAW if str(x).strip().lstrip("-").isdigit()}


def resolve_path(env_name, value, default):
    path = Path(os.getenv(env_name) or value or default)
    if not path.is_absolute():
        path = BASE_DIR / path
    return path.resolve()


DATABASE_PATH = resolve_path("DATABASE_PATH", CONFIG.get("DATABASE_PATH"), "../database.db")
CHARACTERS_CSV = resolve_path("CHARACTERS_CSV", CONFIG.get("CHARACTERS_CSV"), "../GameAssets/csv_logic/characters.csv")
CARDS_CSV = resolve_path("CARDS_CSV", CONFIG.get("CARDS_CSV"), "../GameAssets/csv_logic/cards.csv")
SKINS_CSV = resolve_path("SKINS_CSV", CONFIG.get("SKINS_CSV"), "../GameAssets/csv_logic/skins.csv")
BANNED_ACC_PATH = resolve_path("BANNED_ACC_PATH", CONFIG.get("BANNED_ACC_PATH"), "../banned_acc.json")
BANNED_IP_PATH = resolve_path("BANNED_IP_PATH", CONFIG.get("BANNED_IP_PATH"), "../banned_ip.json")

ROOT_DIR = BASE_DIR.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

CODE_EXPIRY_SECONDS = 600
SAVER_ACCOUNTS_PER_PAGE = 8
try:
    from OgSaver.store import OgSaverStore
    SAVER = OgSaverStore(saver_db_path=ROOT_DIR / "OgSaver" / "ogsaver.db", game_db_path=DATABASE_PATH)
except Exception as _saver_error:
    SAVER = None
    print(f"[OgSaver] unavailable: {_saver_error}")

bot = telebot.TeleBot(BOT_TOKEN or "TOKEN_NAO_CONFIGURADO", parse_mode="HTML")
ALL_TOKEN = "__ALL__"
USER_STATE = {}
PLAYERS_PER_PAGE = 8
ITEMS_PER_PAGE = 8


def db_connect():
    connection = sqlite3.connect(str(DATABASE_PATH), timeout=30)
    connection.row_factory = sqlite3.Row
    return connection


def load_ban_file(path):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def save_ban_file(path, data):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(data, indent=4), encoding="utf-8")
    os.replace(temporary, path)


def add_bans_to_files(low_id, ip, reason):
    banned_acc = load_ban_file(BANNED_ACC_PATH)
    banned_ip = load_ban_file(BANNED_IP_PATH)
    ip = str(ip or "").strip()
    low_key = str(low_id).strip() if low_id not in (None, "") else ""
    if low_key:
        banned_acc[low_key] = {"reason": str(reason or "")}
    if ip:
        banned_ip[ip] = {"reason": str(reason or "")}
    save_ban_file(BANNED_ACC_PATH, banned_acc)
    save_ban_file(BANNED_IP_PATH, banned_ip)
    return bool(low_key), bool(ip)


def remove_bans_from_files(low_id=None, ip=None):
    banned_acc = load_ban_file(BANNED_ACC_PATH)
    banned_ip = load_ban_file(BANNED_IP_PATH)
    low_key = str(low_id).strip() if low_id not in (None, "") else ""
    ip = str(ip or "").strip()
    removed_acc = False
    removed_ip = False
    if low_key and low_key in banned_acc:
        del banned_acc[low_key]
        removed_acc = True
    if ip and ip in banned_ip:
        del banned_ip[ip]
        removed_ip = True
    if removed_acc or removed_ip:
        save_ban_file(BANNED_ACC_PATH, banned_acc)
        save_ban_file(BANNED_IP_PATH, banned_ip)
    return removed_acc, removed_ip


def find_player_by_low_id(low_id):
    for player in load_players():
        if str(player["data"].get("low_id")) == str(low_id):
            return player
    return None


def find_player_by_ip(ip):
    for player in load_players():
        if str(player["data"].get("last_ip") or player["data"].get("lastIp") or "").strip() == str(ip):
            return player
    return None


def banned_entries():
    banned_acc = load_ban_file(BANNED_ACC_PATH)
    banned_ip = load_ban_file(BANNED_IP_PATH)
    entries = []
    for ip, entry in banned_ip.items():
        reason = entry.get("reason", "") if isinstance(entry, dict) else str(entry or "")
        entries.append({"kind": "ip", "key": ip, "label": f"🌐 IP {ip}" + (f" • {reason}" if reason else "")})
    for low_id, entry in banned_acc.items():
        reason = entry.get("reason", "") if isinstance(entry, dict) else str(entry or "")
        entries.append({"kind": "acc", "key": low_id, "label": f"👤 Conta #{low_id}" + (f" • {reason}" if reason else "")})
    return entries


def ban_player_ip(token):
    connection = db_connect()
    try:
        connection.execute("BEGIN IMMEDIATE")
        player = get_player(token, connection)
        if player is None:
            connection.rollback()
            return None
        data = player["data"]
        ip = str(data.get("last_ip") or data.get("lastIp") or "").strip()
        low_id = data.get("low_id", "")
        old_name = data.get("name", "Brawler")
        reason = f"Banido pelo AdminBot: {old_name} #{low_id}"
        data["name_before_ban"] = old_name
        data["name"] = "Account banned"
        connection.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(data), token))
        connection.commit()
        banned_ip_file = False
        ban_error = ""
        try:
            _, banned_ip_file = add_bans_to_files(None, ip, reason)
        except Exception as error:
            ban_error = str(error)
        return {"name": old_name, "low_id": low_id, "ip": ip, "reason": reason, "banned_ip": banned_ip_file, "ban_error": ban_error}
    finally:
        connection.close()


def unban_entry(kind, key):
    low_id = None
    ip = None
    candidates = []
    if kind == "acc":
        low_id = key
        player = find_player_by_low_id(key)
        if player is not None:
            candidates = [player]
            ip = str(player["data"].get("last_ip") or player["data"].get("lastIp") or "").strip()
    else:
        ip = key
        for player in load_players():
            if str(player["data"].get("last_ip") or player["data"].get("lastIp") or "").strip() == str(ip):
                candidates.append(player)
        if candidates:
            low_id = candidates[0]["data"].get("low_id")
    removed_acc, removed_ip = remove_bans_from_files(low_id, ip)
    for player in candidates:
        cand_low = player["data"].get("low_id")
        if cand_low is not None and str(cand_low) != str(low_id):
            extra_acc, _ = remove_bans_from_files(cand_low, None)
            removed_acc = removed_acc or extra_acc
    restored_name = ""
    for player in candidates:
        data = player["data"]
        if data.get("name") == "Account banned" and data.get("name_before_ban"):
            data["name"] = data.pop("name_before_ban")
            save_player(player["token"], data)
            restored_name = data["name"]
    return {"removed_acc": removed_acc, "removed_ip": removed_ip, "restored_name": restored_name, "low_id": low_id, "ip": ip}


def safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def player_key(token):
    return hashlib.sha256(str(token).encode("utf-8")).hexdigest()[:16]


def load_players():
    players = []
    connection = db_connect()
    try:
        rows = connection.execute("SELECT token, data FROM Players").fetchall()
    finally:
        connection.close()
    for row in rows:
        try:
            data = json.loads(row["data"] or "{}")
        except Exception:
            data = {}
        if not isinstance(data, dict):
            data = {}
        players.append({"token": row["token"], "data": data})
    players.sort(key=lambda item: (safe_int(item["data"].get("low_id"), 999999999), str(item["data"].get("name", ""))))
    return players


def get_player(token, connection=None):
    own_connection = connection is None
    if own_connection:
        connection = db_connect()
    try:
        row = connection.execute("SELECT token, data FROM Players WHERE token = ?", (token,)).fetchone()
        if row is None:
            return None
        try:
            data = json.loads(row["data"] or "{}")
        except Exception:
            data = {}
        return {"token": row["token"], "data": data if isinstance(data, dict) else {}}
    finally:
        if own_connection:
            connection.close()


def all_players_target():
    players = load_players()
    brawlers = {}
    if players:
        per_player = []
        for player in players:
            copied = json.loads(json.dumps(player["data"] if isinstance(player.get("data"), dict) else {}))
            per_player.append(normalize_brawlers(copied))
        common_ids = set(per_player[0].keys())
        for owned in per_player[1:]:
            common_ids.intersection_update(owned.keys())
        for key in common_ids:
            skins = None
            for owned in per_player:
                current = {safe_int(skin) for skin in owned.get(key, {}).get("Skins", [])}
                skins = current if skins is None else skins & current
            item = new_brawler_data(int(key))
            item["Skins"] = sorted(skins or {0})
            if 0 not in item["Skins"]:
                item["Skins"].insert(0, 0)
            brawlers[str(key)] = item
    return {
        "token": ALL_TOKEN,
        "data": {
            "name": "Todos os jogadores",
            "low_id": "TODOS",
            "players_count": len(players),
            "unlocked_brawlers": brawlers,
        },
    }


def refresh_target(player):
    if player and player.get("token") == ALL_TOKEN:
        return all_players_target()
    return get_player(player["token"]) if player else None


def find_player_by_key(key):
    for player in load_players():
        if player_key(player["token"]) == key:
            return player
    return None


def save_player(token, data, connection=None):
    own_connection = connection is None
    if own_connection:
        connection = db_connect()
    try:
        connection.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(data), token))
        if own_connection:
            connection.commit()
    finally:
        if own_connection:
            connection.close()


def read_csv_rows(path):
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8-sig") as file:
        rows = list(csv.reader(file))
    return rows[2:] if len(rows) > 2 else []


def load_catalogs():
    characters = {}
    internal_names = {}
    for brawler_id, row in enumerate(read_csv_rows(CHARACTERS_CSV)):
        if len(row) > 20:
            internal_names[row[0]] = brawler_id
            if brawler_id <= 20 and row[20] == "Hero" and row[2].lower() != "true" and row[1].lower() != "true":
                display = row[3].replace("_", " ").title() if len(row) > 3 and row[3] else row[0]
                characters[brawler_id] = {"name": display, "internal": row[0]}
    unlock_cards = {}
    for card_id, row in enumerate(read_csv_rows(CARDS_CSV)):
        if len(row) > 4 and row[4].strip() == "0":
            brawler_id = internal_names.get(row[3])
            if brawler_id is not None:
                unlock_cards[brawler_id] = card_id
    skins = {}
    skins_by_brawler = {}
    for skin_id, row in enumerate(read_csv_rows(SKINS_CSV)):
        if skin_id > 49 or len(row) <= 2 or not row[2]:
            continue
        brawler_id = internal_names.get(row[2])
        if brawler_id is None or brawler_id not in characters:
            continue
        skins[skin_id] = {"name": row[0], "brawler_id": brawler_id}
        skins_by_brawler.setdefault(brawler_id, []).append(skin_id)
    default_skins = set()
    character_rows = read_csv_rows(CHARACTERS_CSV)
    skin_names = {skin["name"]: skin_id for skin_id, skin in skins.items()}
    for row in character_rows:
        if len(row) > 22 and row[22] in skin_names:
            default_skins.add(skin_names[row[22]])
    return characters, unlock_cards, skins, skins_by_brawler, default_skins


CHARACTERS, UNLOCK_CARDS, SKINS, SKINS_BY_BRAWLER, DEFAULT_SKINS = load_catalogs()


def brawler_name(brawler_id):
    info = CHARACTERS.get(int(brawler_id))
    return info["name"] if info else f"Brawler {brawler_id}"


def skin_name(skin_id):
    info = SKINS.get(int(skin_id))
    return info["name"] if info else f"Skin {skin_id}"


def normalize_brawlers(data):
    brawlers = data.get("unlocked_brawlers")
    if not isinstance(brawlers, dict):
        brawlers = {}
    normalized = {}
    for key, value in brawlers.items():
        if not isinstance(value, dict):
            continue
        item = dict(value)
        item.setdefault("CardID", UNLOCK_CARDS.get(safe_int(key), 0))
        item.setdefault("Skins", [0])
        item.setdefault("selectedSkin", 0)
        item.setdefault("Trophies", 0)
        item.setdefault("HighestTrophies", item.get("Trophies", 0))
        item.setdefault("PowerLevel", 0)
        item.setdefault("PowerPoints", 0)
        item.setdefault("State", 0)
        item.setdefault("StarPower", 0)
        if not isinstance(item["Skins"], list):
            item["Skins"] = [0]
        item["Skins"] = [safe_int(skin) for skin in item["Skins"]]
        if 0 not in item["Skins"]:
            item["Skins"].insert(0, 0)
        normalized[str(key)] = item
    data["unlocked_brawlers"] = normalized
    return normalized


def new_brawler_data(brawler_id):
    return {
        "CardID": UNLOCK_CARDS.get(int(brawler_id), 0),
        "Skins": [0],
        "selectedSkin": 0,
        "Trophies": 0,
        "HighestTrophies": 0,
        "PowerLevel": 0,
        "PowerPoints": 0,
        "State": 0,
        "StarPower": 0,
    }


def ensure_brawler(data, brawler_id):
    brawlers = normalize_brawlers(data)
    key = str(int(brawler_id))
    if key not in brawlers:
        brawlers[key] = new_brawler_data(int(brawler_id))
        return True
    return False


def apply_numeric_resource(token, resource, quantity):
    connection = db_connect()
    try:
        connection.execute("BEGIN IMMEDIATE")
        player = get_player(token, connection)
        if player is None:
            connection.rollback()
            return None
        data = player["data"]
        result = {}
        if resource in ("gems", "gold"):
            old = safe_int(data.get(resource))
            new = max(0, old + int(quantity))
            data[resource] = new
            result = {"old": old, "new": new, "applied": new - old}
        elif resource == "trophies":
            old = safe_int(data.get("trophies"))
            new = max(0, old + int(quantity))
            applied = new - old
            data["trophies"] = new
            data["highest_trophies"] = max(safe_int(data.get("highest_trophies")), new)
            brawlers = normalize_brawlers(data)
            selected = str(safe_int(data.get("brawler_id")))
            if selected not in brawlers and brawlers:
                selected = sorted(brawlers, key=lambda value: safe_int(value))[0]
            if selected in brawlers:
                old_brawler = safe_int(brawlers[selected].get("Trophies"))
                new_brawler = max(0, old_brawler + applied)
                brawlers[selected]["Trophies"] = new_brawler
                brawlers[selected]["HighestTrophies"] = max(
                    safe_int(brawlers[selected].get("HighestTrophies")), new_brawler
                )
                result["brawler_id"] = int(selected)
                result["brawler_old"] = old_brawler
                result["brawler_new"] = new_brawler
            result.update({"old": old, "new": new, "applied": applied})
        else:
            connection.rollback()
            return None
        save_player(token, data, connection)
        connection.commit()
        result["player"] = {"token": token, "data": data}
        return result
    finally:
        connection.close()


def unlock_brawlers(token, brawler_ids=None, quantity=None):
    connection = db_connect()
    try:
        connection.execute("BEGIN IMMEDIATE")
        player = get_player(token, connection)
        if player is None:
            connection.rollback()
            return None
        data = player["data"]
        brawlers = normalize_brawlers(data)
        locked = [brawler_id for brawler_id in sorted(CHARACTERS) if str(brawler_id) not in brawlers]
        if brawler_ids is None:
            targets = locked[: max(0, int(quantity or 0))]
        else:
            targets = [int(brawler_id) for brawler_id in brawler_ids if int(brawler_id) in CHARACTERS and str(int(brawler_id)) not in brawlers]
        added = []
        for brawler_id in targets:
            brawlers[str(brawler_id)] = new_brawler_data(brawler_id)
            added.append(brawler_id)
        data["unlocked_brawlers"] = brawlers
        save_player(token, data, connection)
        connection.commit()
        return {"added": added, "player": {"token": token, "data": data}, "locked_before": locked}
    finally:
        connection.close()


def unlock_skins(token, skin_ids=None, quantity=None):
    connection = db_connect()
    try:
        connection.execute("BEGIN IMMEDIATE")
        player = get_player(token, connection)
        if player is None:
            connection.rollback()
            return None
        data = player["data"]
        brawlers = normalize_brawlers(data)
        if skin_ids is None:
            candidates = []
            for skin_id in sorted(SKINS):
                if skin_id in DEFAULT_SKINS:
                    continue
                owner = SKINS[skin_id]["brawler_id"]
                owned = brawlers.get(str(owner), {}).get("Skins", []) if str(owner) in brawlers else []
                if skin_id not in owned:
                    candidates.append(skin_id)
            targets = candidates[: max(0, int(quantity or 0))]
        else:
            targets = [int(skin_id) for skin_id in skin_ids if int(skin_id) in SKINS]
        added = []
        unlocked_owners = []
        for skin_id in targets:
            owner = SKINS[skin_id]["brawler_id"]
            if ensure_brawler(data, owner):
                unlocked_owners.append(owner)
            owned = data["unlocked_brawlers"][str(owner)].setdefault("Skins", [0])
            if skin_id not in owned:
                owned.append(skin_id)
                added.append(skin_id)
        save_player(token, data, connection)
        connection.commit()
        return {"added": added, "unlocked_owners": unlocked_owners, "player": {"token": token, "data": data}}
    finally:
        connection.close()


def apply_numeric_resource_all(resource, quantity):
    updated = 0
    total_applied = 0
    for player in load_players():
        result = apply_numeric_resource(player["token"], resource, quantity)
        if result is not None:
            updated += 1
            total_applied += safe_int(result.get("applied"))
    return {"players": updated, "total_applied": total_applied}


def unlock_brawlers_all(brawler_ids=None, quantity=None):
    added = set()
    grants = 0
    affected = 0
    for player in load_players():
        result = unlock_brawlers(player["token"], brawler_ids=brawler_ids, quantity=quantity)
        if result and result.get("added"):
            affected += 1
            grants += len(result["added"])
            added.update(result["added"])
    return {"added": sorted(added), "grants": grants, "players": affected}


def unlock_skins_all(skin_ids=None, quantity=None):
    added = set()
    grants = 0
    affected = 0
    for player in load_players():
        result = unlock_skins(player["token"], skin_ids=skin_ids, quantity=quantity)
        if result and result.get("added"):
            affected += 1
            grants += len(result["added"])
            added.update(result["added"])
    return {"added": sorted(added), "grants": grants, "players": affected}


def delete_player_and_ban(token):
    connection = db_connect()
    try:
        connection.execute("BEGIN IMMEDIATE")
        player = get_player(token, connection)
        if player is None:
            connection.rollback()
            return None
        data = player["data"]
        ip = str(data.get("last_ip") or data.get("lastIp") or "").strip()
        low_id = data.get("low_id", "")
        reason = f"Conta excluida pelo AdminBot: {data.get('name', 'Brawler')} #{low_id}"
        try:
            connection.execute("DELETE FROM PlayerOffers WHERE PlayerToken = ?", (token,))
        except sqlite3.Error:
            pass
        try:
            match_rows = connection.execute("SELECT slot, data FROM Matchmake").fetchall()
            for match in match_rows:
                try:
                    match_data = json.loads(match["data"] or "{}")
                    match_players = match_data.get("info", {}).get("players", {})
                except Exception:
                    continue
                if isinstance(match_players, dict) and token in match_players:
                    del match_players[token]
                    match_data["info"]["players"] = match_players
                    match_data["info"]["PlayerCount"] = len(match_players)
                    if match_players:
                        connection.execute("UPDATE Matchmake SET data = ? WHERE slot = ?", (json.dumps(match_data), match["slot"]))
                    else:
                        connection.execute("DELETE FROM Matchmake WHERE slot = ?", (match["slot"],))
        except sqlite3.Error:
            pass
        rows = connection.execute("SELECT token, data FROM Players WHERE token != ?", (token,)).fetchall()
        for row in rows:
            try:
                other = json.loads(row["data"] or "{}")
            except Exception:
                continue
            friends = other.get("friends")
            changed = False
            if isinstance(friends, dict) and token in friends:
                del friends[token]
                changed = True
            elif isinstance(friends, list) and token in friends:
                other["friends"] = [item for item in friends if item != token]
                changed = True
            if changed:
                connection.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(other), row["token"]))
        try:
            clubs = connection.execute("SELECT club_id, data FROM Clubs").fetchall()
            for club in clubs:
                try:
                    club_data = json.loads(club["data"] or "{}")
                    members = club_data.get("info", {}).get("memberCount", [])
                except Exception:
                    continue
                if isinstance(members, list) and token in members:
                    members = [member for member in members if member != token]
                    club_data["info"]["memberCount"] = members
                    if members:
                        connection.execute("UPDATE Clubs SET data = ? WHERE club_id = ?", (json.dumps(club_data), club["club_id"]))
                    else:
                        connection.execute("DELETE FROM Clubs WHERE club_id = ?", (club["club_id"],))
                        try:
                            connection.execute("DELETE FROM ClubChats WHERE club_id = ?", (club["club_id"],))
                        except sqlite3.Error:
                            pass
        except sqlite3.Error:
            pass
        try:
            rooms = connection.execute("SELECT room_id, data FROM Gamerooms").fetchall()
            for room in rooms:
                try:
                    room_data = json.loads(room["data"] or "{}")
                    room_players = room_data.get("info", {}).get("players", {})
                except Exception:
                    continue
                if isinstance(room_players, dict) and str(low_id) in room_players:
                    del room_players[str(low_id)]
                    room_data["info"]["players"] = room_players
                    room_data["info"]["player_count"] = len(room_players)
                    if room_players:
                        connection.execute("UPDATE Gamerooms SET data = ? WHERE room_id = ?", (json.dumps(room_data), room["room_id"]))
                    else:
                        connection.execute("DELETE FROM Gamerooms WHERE room_id = ?", (room["room_id"],))
                        try:
                            connection.execute("DELETE FROM GameroomChats WHERE room_id = ?", (room["room_id"],))
                        except sqlite3.Error:
                            pass
        except sqlite3.Error:
            pass
        connection.execute("DELETE FROM Players WHERE token = ?", (token,))
        connection.commit()
        banned_acc = False
        banned_ip_file = False
        ban_error = ""
        try:
            banned_acc, banned_ip_file = add_bans_to_files(low_id, ip, reason)
        except Exception as error:
            ban_error = str(error)
        return {"name": data.get("name", "Brawler"), "low_id": low_id, "ip": ip, "reason": reason, "banned_acc": banned_acc, "banned_ip": banned_ip_file, "ban_error": ban_error}
    finally:
        connection.close()


def is_admin(user_id):
    return int(user_id) in ADMIN_IDS


def deny_message(message):
    bot.reply_to(message, f"Você não tem permissão. Seu ID do Telegram é <code>{message.from_user.id}</code>.")


def esc(value):
    return html.escape(str(value if value is not None else ""))


def player_button_label(player):
    data = player["data"]
    name = data.get("name") or "Brawler"
    return f"{name} • #{data.get('low_id', '?')} • 🏆 {safe_int(data.get('trophies'))}"[:64]


def player_details(player):
    if player.get("token") == ALL_TOKEN:
        total = player.get("data", {}).get("players_count")
        if total is None:
            total = len(load_players())
        return (
            "📣 <b>Enviar para todos</b>\n"
            f"Contas na database: <b>{total}</b>\n"
            "Tudo que você enviar aqui será aplicado em <b>todas as contas</b>."
        )
    data = player["data"]
    brawlers = data.get("unlocked_brawlers") if isinstance(data.get("unlocked_brawlers"), dict) else {}
    skins = 0
    for item in brawlers.values():
        if isinstance(item, dict) and isinstance(item.get("Skins"), list):
            skins += len([skin for skin in item["Skins"] if safe_int(skin) != 0])
    club = safe_int(data.get("club_id"))
    return (
        f"👤 <b>{esc(data.get('name') or 'Brawler')}</b>\n"
        f"ID da conta: <code>#{esc(data.get('low_id', '?'))}</code>\n"
        f"💎 Gemas: <b>{safe_int(data.get('gems'))}</b>\n"
        f"🪙 Moedas: <b>{safe_int(data.get('gold'))}</b>\n"
        f"🏆 Troféus: <b>{safe_int(data.get('trophies'))}</b>\n"
        f"🥊 Brawlers: <b>{len(brawlers)}</b>\n"
        f"👕 Skins extras: <b>{skins}</b>\n"
        f"🏠 Clube: <b>{club if club else 'Sem clube'}</b>\n"
        f"🌐 Último IP: <code>{esc(data.get('last_ip') or 'Não salvo')}</code>"
    )


def main_markup():
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("👥 Players", callback_data="pl:0"),
        types.InlineKeyboardButton("🗑️ Delete", callback_data="dl:0"),
    )
    markup.add(
        types.InlineKeyboardButton("🚫 Ban", callback_data="bn:0"),
        types.InlineKeyboardButton("♻️ Desban", callback_data="un:0"),
    )
    markup.add(types.InlineKeyboardButton("OgSaver", callback_data="og:menu"))
    return markup


def pagination_markup(prefix, page, total, per_page):
    buttons = []
    if page > 0:
        buttons.append(types.InlineKeyboardButton("⬅️ Anterior", callback_data=f"{prefix}:{page - 1}"))
    if (page + 1) * per_page < total:
        buttons.append(types.InlineKeyboardButton("Próxima ➡️", callback_data=f"{prefix}:{page + 1}"))
    return buttons


def players_markup(page=0):
    players = load_players()
    total = len(players)
    page = max(0, min(int(page), max(0, (total - 1) // PLAYERS_PER_PAGE)))
    markup = types.InlineKeyboardMarkup(row_width=1)
    if total:
        markup.add(types.InlineKeyboardButton("📣 Enviar para todos", callback_data=f"pa:{page}"))
    for player in players[page * PLAYERS_PER_PAGE:(page + 1) * PLAYERS_PER_PAGE]:
        markup.add(types.InlineKeyboardButton(player_button_label(player), callback_data=f"ps:{player_key(player['token'])}:{page}"))
    nav = pagination_markup("pl", page, total, PLAYERS_PER_PAGE)
    if nav:
        markup.row(*nav)
    markup.add(types.InlineKeyboardButton("🏠 Menu", callback_data="menu"))
    return markup, total, page


def delete_markup(page=0):
    players = load_players()
    total = len(players)
    page = max(0, min(int(page), max(0, (total - 1) // PLAYERS_PER_PAGE)))
    markup = types.InlineKeyboardMarkup(row_width=1)
    for player in players[page * PLAYERS_PER_PAGE:(page + 1) * PLAYERS_PER_PAGE]:
        markup.add(types.InlineKeyboardButton(f"🗑️ {player_button_label(player)}", callback_data=f"dd:{player_key(player['token'])}:{page}"))
    nav = pagination_markup("dl", page, total, PLAYERS_PER_PAGE)
    if nav:
        markup.row(*nav)
    markup.add(types.InlineKeyboardButton("🏠 Menu", callback_data="menu"))
    return markup, total, page


def ban_markup(page=0):
    players = load_players()
    total = len(players)
    page = max(0, min(int(page), max(0, (total - 1) // PLAYERS_PER_PAGE)))
    markup = types.InlineKeyboardMarkup(row_width=1)
    for player in players[page * PLAYERS_PER_PAGE:(page + 1) * PLAYERS_PER_PAGE]:
        markup.add(types.InlineKeyboardButton(f"🚫 {player_button_label(player)}", callback_data=f"bb:{player_key(player['token'])}:{page}"))
    nav = pagination_markup("bn", page, total, PLAYERS_PER_PAGE)
    if nav:
        markup.row(*nav)
    markup.add(types.InlineKeyboardButton("🏠 Menu", callback_data="menu"))
    return markup, total, page


def unban_markup(page=0):
    entries = banned_entries()
    total = len(entries)
    page = max(0, min(int(page), max(0, (total - 1) // PLAYERS_PER_PAGE)))
    markup = types.InlineKeyboardMarkup(row_width=1)
    for entry in entries[page * PLAYERS_PER_PAGE:(page + 1) * PLAYERS_PER_PAGE]:
        markup.add(types.InlineKeyboardButton(f"♻️ {entry['label']}"[:64], callback_data=f"uu:{entry['kind']}:{entry['key']}:{page}"))
    nav = pagination_markup("un", page, total, PLAYERS_PER_PAGE)
    if nav:
        markup.row(*nav)
    markup.add(types.InlineKeyboardButton("🏠 Menu", callback_data="menu"))
    return markup, total, page


def selected_player_markup(page=0):
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton("➕ Add Resources", callback_data="resources"))
    markup.add(types.InlineKeyboardButton("👥 Voltar para Players", callback_data=f"pl:{page}"))
    markup.add(types.InlineKeyboardButton("🏠 Menu", callback_data="menu"))
    return markup


def resources_markup():
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("💎 Gemas", callback_data="qty:gems"),
        types.InlineKeyboardButton("🪙 Moedas", callback_data="qty:gold"),
        types.InlineKeyboardButton("🏆 Troféus", callback_data="qty:trophies"),
        types.InlineKeyboardButton("🥊 Brawler", callback_data="brmenu:0"),
        types.InlineKeyboardButton("👕 Skins", callback_data="skmenu:0"),
    )
    markup.add(types.InlineKeyboardButton("👤 Voltar para o jogador", callback_data="backplayer"))
    markup.add(types.InlineKeyboardButton("🏠 Menu", callback_data="menu"))
    return markup


def brawlers_markup(player, page=0):
    brawlers = normalize_brawlers(dict(player["data"]))
    ids = sorted(CHARACTERS)
    total = len(ids)
    page = max(0, min(int(page), max(0, (total - 1) // ITEMS_PER_PAGE)))
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton("🔢 Desbloquear por quantidade", callback_data="qty:brawlers"))
    markup.add(types.InlineKeyboardButton("✅ Desbloquear todos os brawlers", callback_data="uball"))
    for brawler_id in ids[page * ITEMS_PER_PAGE:(page + 1) * ITEMS_PER_PAGE]:
        owned = str(brawler_id) in brawlers
        label = f"{'✅' if owned else '🔒'} {brawler_name(brawler_id)} (#{brawler_id})"
        markup.add(types.InlineKeyboardButton(label, callback_data="noop" if owned else f"ub:{brawler_id}:{page}"))
    nav = pagination_markup("brmenu", page, total, ITEMS_PER_PAGE)
    if nav:
        markup.row(*nav)
    markup.add(types.InlineKeyboardButton("⬅️ Recursos", callback_data="resources"))
    return markup, page


def skin_brawlers_markup(player, page=0):
    brawlers = normalize_brawlers(dict(player["data"]))
    ids = [brawler_id for brawler_id in sorted(CHARACTERS) if SKINS_BY_BRAWLER.get(brawler_id)]
    total = len(ids)
    page = max(0, min(int(page), max(0, (total - 1) // ITEMS_PER_PAGE)))
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton("🔢 Desbloquear skins por quantidade", callback_data="qty:skins"))
    markup.add(types.InlineKeyboardButton("✅ Desbloquear todas as skins", callback_data="usall"))
    for brawler_id in ids[page * ITEMS_PER_PAGE:(page + 1) * ITEMS_PER_PAGE]:
        owned_skins = brawlers.get(str(brawler_id), {}).get("Skins", []) if str(brawler_id) in brawlers else []
        count = len([skin for skin in owned_skins if safe_int(skin) != 0])
        status = "✅" if str(brawler_id) in brawlers else "🔒"
        markup.add(types.InlineKeyboardButton(
            f"{status} {brawler_name(brawler_id)} • {count}/{len(SKINS_BY_BRAWLER[brawler_id])}",
            callback_data=f"sb:{brawler_id}:0:{page}",
        ))
    nav = pagination_markup("skmenu", page, total, ITEMS_PER_PAGE)
    if nav:
        markup.row(*nav)
    markup.add(types.InlineKeyboardButton("⬅️ Recursos", callback_data="resources"))
    return markup, page


def skins_markup(player, brawler_id, page=0, parent_page=0):
    brawlers = normalize_brawlers(dict(player["data"]))
    owned = brawlers.get(str(brawler_id), {}).get("Skins", []) if str(brawler_id) in brawlers else []
    ids = SKINS_BY_BRAWLER.get(int(brawler_id), [])
    total = len(ids)
    page = max(0, min(int(page), max(0, (total - 1) // ITEMS_PER_PAGE)))
    markup = types.InlineKeyboardMarkup(row_width=1)
    for skin_id in ids[page * ITEMS_PER_PAGE:(page + 1) * ITEMS_PER_PAGE]:
        has = skin_id in owned or skin_id in DEFAULT_SKINS
        label = f"{'✅' if has else '🔒'} {skin_name(skin_id)} (#{skin_id})"
        markup.add(types.InlineKeyboardButton(label, callback_data="noop" if has else f"us:{skin_id}:{brawler_id}:{page}:{parent_page}"))
    nav = []
    if page > 0:
        nav.append(types.InlineKeyboardButton("⬅️ Anterior", callback_data=f"sb:{brawler_id}:{page - 1}:{parent_page}"))
    if (page + 1) * ITEMS_PER_PAGE < total:
        nav.append(types.InlineKeyboardButton("Próxima ➡️", callback_data=f"sb:{brawler_id}:{page + 1}:{parent_page}"))
    if nav:
        markup.row(*nav)
    markup.add(types.InlineKeyboardButton("⬅️ Brawlers das skins", callback_data=f"skmenu:{parent_page}"))
    return markup, page


def show(call, text, markup=None):
    try:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception as error:
        if "message is not modified" not in str(error).lower():
            bot.send_message(call.message.chat.id, text, reply_markup=markup)


def state_for(user_id):
    return USER_STATE.setdefault(int(user_id), {})


def current_player(user_id):
    token = state_for(user_id).get("token")
    if not token:
        return None
    if token == ALL_TOKEN:
        return all_players_target()
    return get_player(token)


def show_main(call_or_message):
    text = "🎮 <b>Painel do servidor</b>\nEscolha uma opção:"
    if hasattr(call_or_message, "message"):
        show(call_or_message, text, main_markup())
    else:
        bot.send_message(call_or_message.chat.id, text, reply_markup=main_markup())


def show_players(call_or_message, page=0):
    markup, total, page = players_markup(page)
    text = f"👥 <b>Players</b> ({total})\nSelecione um jogador ou <b>Enviar para todos</b>:" if total else "👥 <b>Players</b>\nNenhuma conta encontrada na database."
    if hasattr(call_or_message, "message"):
        show(call_or_message, text, markup)
    else:
        bot.send_message(call_or_message.chat.id, text, reply_markup=markup)


def show_delete(call_or_message, page=0):
    markup, total, page = delete_markup(page)
    text = (
        f"🗑️ <b>Delete</b> ({total})\n"
        "Toque em uma conta para <b>excluir a conta e banir o IP salvo</b> imediatamente."
        if total else "🗑️ <b>Delete</b>\nNenhuma conta encontrada na database."
    )
    if hasattr(call_or_message, "message"):
        show(call_or_message, text, markup)
    else:
        bot.send_message(call_or_message.chat.id, text, reply_markup=markup)


def show_ban(call_or_message, page=0):
    markup, total, page = ban_markup(page)
    text = (
        f"🚫 <b>Ban</b> ({total})\n"
        "Toque em uma conta para <b>banir somente o IP salvo</b> e trocar o nome da conta para <b>Account banned</b>. A conta não é excluída."
        if total else "🚫 <b>Ban</b>\nNenhuma conta encontrada na database."
    )
    if hasattr(call_or_message, "message"):
        show(call_or_message, text, markup)
    else:
        bot.send_message(call_or_message.chat.id, text, reply_markup=markup)


def show_unban(call_or_message, page=0):
    markup, total, page = unban_markup(page)
    text = (
        f"♻️ <b>Desban</b> ({total})\nToque em um ban para removê-lo dos arquivos. O IP e a conta ligados são desbanidos juntos."
        if total else "♻️ <b>Desban</b>\nNenhum ban encontrado em banned_ip.json / banned_acc.json."
    )
    if hasattr(call_or_message, "message"):
        show(call_or_message, text, markup)
    else:
        bot.send_message(call_or_message.chat.id, text, reply_markup=markup)


def show_player(call, player, page=0):
    show(call, player_details(player), selected_player_markup(page))


def show_resources(call, player):
    show(call, f"➕ <b>Add Resources</b>\n\n{player_details(player)}\n\nEscolha o recurso:", resources_markup())


def resource_label(resource):
    return {
        "gems": "💎 gemas",
        "gold": "🪙 moedas",
        "trophies": "🏆 troféus",
        "brawlers": "🥊 brawlers bloqueados",
        "skins": "👕 skins bloqueadas",
    }.get(resource, resource)


def parse_quantity(text):
    value = str(text or "").strip().replace(" ", "").replace(".", "").replace(",", "")
    if value.startswith("+"):
        value = value[1:]
    if not value or not value.lstrip("-").isdigit():
        return None
    return int(value)


def format_names(items, formatter):
    if not items:
        return "Nenhum item novo."
    names = [formatter(item) for item in items[:20]]
    extra = f"\n... e mais {len(items) - 20}." if len(items) > 20 else ""
    return "\n".join(f"• {esc(name)}" for name in names) + extra


def saver_button(text, callback_data, style=None):
    kwargs = {"callback_data": callback_data}
    parameters = inspect.signature(types.InlineKeyboardButton.__init__).parameters
    if style and "style" in parameters:
        kwargs["style"] = style
    button = types.InlineKeyboardButton(text, **kwargs)
    if style:
        try:
            button.style = style
        except Exception:
            pass
    return button


def saver_main_markup(user_id):
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(saver_button("Register account", "og:register"))
    markup.add(saver_button("My accounts", "og:accounts:0", style="success"))
    markup.add(saver_button("Add another account", "og:add"))
    if is_admin(user_id):
        markup.add(types.InlineKeyboardButton("Admin panel", callback_data="menu"))
    return markup


def show_saver_main(chat_id, user_id, message_id=None):
    markup = saver_main_markup(user_id)
    for text in ("\u3164", "\u2063", "Menu"):
        try:
            if message_id:
                bot.edit_message_text(text, chat_id=chat_id, message_id=message_id, reply_markup=markup, disable_web_page_preview=True)
            else:
                bot.send_message(chat_id, text, reply_markup=markup, disable_web_page_preview=True)
            return
        except Exception as error:
            if "message is not modified" in str(error):
                return
            if message_id and "non-empty" not in str(error):
                message_id = None
            continue


def saver_show(call, text, markup=None):
    try:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup, disable_web_page_preview=True)
    except Exception as error:
        if "message is not modified" not in str(error).lower():
            bot.send_message(call.message.chat.id, text, reply_markup=markup, disable_web_page_preview=True)


def saver_account_label(account):
    name = account.get("current_name") or account.get("account_name") or "Brawler"
    low_id = account.get("low_id") or "?"
    if not account.get("exists"):
        return f"{name} | #{low_id} | unavailable"[:64]
    return f"{name} | #{low_id} | {int(account.get('trophies') or 0)} trophies"[:64]


def saver_accounts_markup(user_id, page=0):
    accounts = SAVER.list_accounts(user_id)
    total = len(accounts)
    max_page = max(0, (total - 1) // SAVER_ACCOUNTS_PER_PAGE)
    page = max(0, min(int(page), max_page))
    markup = types.InlineKeyboardMarkup(row_width=1)
    for account in accounts[page * SAVER_ACCOUNTS_PER_PAGE:(page + 1) * SAVER_ACCOUNTS_PER_PAGE]:
        markup.add(saver_button(saver_account_label(account), f"og:redeem:{int(account['id'])}:{page}"))
    navigation = []
    if page > 0:
        navigation.append(saver_button("Previous", f"og:accounts:{page - 1}"))
    if (page + 1) * SAVER_ACCOUNTS_PER_PAGE < total:
        navigation.append(saver_button("Next", f"og:accounts:{page + 1}"))
    if navigation:
        markup.row(*navigation)
    markup.add(saver_button("Add another account", "og:add"))
    markup.add(saver_button("Main menu", "og:menu"))
    if is_admin(user_id):
        markup.add(types.InlineKeyboardButton("Admin panel", callback_data="menu"))
    return markup, total, page


def saver_code_markup(user_id):
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(saver_button("My accounts", "og:accounts:0", style="success"))
    markup.add(saver_button("Cancel this code", "og:cancel"))
    markup.add(saver_button("Main menu", "og:menu"))
    if is_admin(user_id):
        markup.add(types.InlineKeyboardButton("Admin panel", callback_data="menu"))
    return markup


def saver_register_text(code):
    minutes = max(1, CODE_EXPIRY_SECONDS // 60)
    return (
        "<b>Registration code ready</b>\n\n"
        "Open the game with the account you want to save and send this message in your club chat:\n\n"
        f"<code>/code {esc(code)}</code>\n\n"
        f"The code expires in {minutes} minutes. "
        "If you are not in a club yet, join any club first, because the code only works in the club chat.\n\n"
        "As soon as the server receives the code, your account will be saved."
    )


def saver_send_register(call):
    pending = SAVER.create_pending(call.from_user.id, "register", expiry_seconds=CODE_EXPIRY_SECONDS)
    if pending is None:
        bot.answer_callback_query(call.id, "Could not create the registration code.", show_alert=True)
        return False
    saver_show(call, saver_register_text(pending["code"]), saver_code_markup(call.from_user.id))
    return True


def saver_accounts_text(total):
    if total == 0:
        return (
            "<b>My accounts</b>\n\n"
            "You do not have any saved accounts yet.\n"
            "Use <b>Register account</b> to save your first account."
        )
    return (
        "<b>My accounts</b>\n\n"
        f"You have <b>{total}</b> saved account(s).\n"
        "Tap an account to create its redeem code."
    )


def saver_show_accounts(call, page=0):
    markup, total, page = saver_accounts_markup(call.from_user.id, page)
    saver_show(call, saver_accounts_text(total), markup)
    return True


def saver_send_redeem(call, saved_account_id, page=0):
    account = SAVER.get_saved_account(call.from_user.id, saved_account_id)
    if account is None:
        bot.answer_callback_query(call.id, "This saved account was not found.", show_alert=True)
        saver_show_accounts(call, page)
        return False
    if not account.get("exists"):
        bot.answer_callback_query(call.id, "This game account no longer exists on the server.", show_alert=True)
        saver_show_accounts(call, page)
        return False
    pending = SAVER.create_pending(call.from_user.id, "redeem", saved_account_id=saved_account_id, expiry_seconds=CODE_EXPIRY_SECONDS)
    if pending is None:
        bot.answer_callback_query(call.id, "Could not create the redeem code.", show_alert=True)
        return False
    minutes = max(1, CODE_EXPIRY_SECONDS // 60)
    name = account.get("current_name") or account.get("account_name") or "Brawler"
    text = (
        "<b>Redeem code ready</b>\n\n"
        f"Account: <b>{esc(name)}</b> <code>#{esc(account.get('low_id'))}</code>\n\n"
        "Open the game on the device where you want to use this account and send this message in your club chat. "
        "It does not matter which account is currently logged in:\n\n"
        f"<code>/load {esc(pending['code'])}</code>\n\n"
        f"The code expires in {minutes} minutes. "
        "If that account is not in a club yet, join any club first, because the code only works in the club chat."
    )
    saver_show(call, text, saver_code_markup(call.from_user.id))
    return True


def saver_callback(call):
    if getattr(call.message.chat, "type", "private") != "private":
        bot.answer_callback_query(call.id, "Please use OgSaver in a private chat.", show_alert=True)
        return
    if SAVER is None:
        bot.answer_callback_query(call.id, "OgSaver is unavailable.", show_alert=True)
        return
    data = call.data or ""
    try:
        if data == "og:menu":
            bot.answer_callback_query(call.id)
            show_saver_main(call.message.chat.id, call.from_user.id, call.message.message_id)
        elif data in ("og:register", "og:add"):
            if saver_send_register(call):
                bot.answer_callback_query(call.id)
        elif data.startswith("og:accounts:"):
            bot.answer_callback_query(call.id)
            saver_show_accounts(call, safe_int(data.split(":")[2]))
        elif data.startswith("og:redeem:"):
            parts = data.split(":")
            if saver_send_redeem(call, safe_int(parts[2]), safe_int(parts[3]) if len(parts) > 3 else 0):
                bot.answer_callback_query(call.id)
        elif data == "og:cancel":
            SAVER.cancel_pending(call.from_user.id)
            bot.answer_callback_query(call.id, "The pending code was cancelled.")
            show_saver_main(call.message.chat.id, call.from_user.id, call.message.message_id)
        else:
            bot.answer_callback_query(call.id, "Unknown option.")
    except Exception as error:
        try:
            bot.answer_callback_query(call.id, "Something went wrong.", show_alert=True)
        except Exception:
            pass
        bot.send_message(call.message.chat.id, f"Error: <code>{esc(error)}</code>")


def saver_notification_text(item):
    kind = item.get("kind")
    name = item.get("matched_account_name") or item.get("target_account_name") or "Brawler"
    if kind == "register_completed":
        text = f"Account {esc(name)} saved"
        if item.get("reward_summary"):
            text += f"\n\n{esc(item['reward_summary'])}"
        return text
    if kind == "redeem_armed":
        return f"Redeem detected for account <b>{esc(name)}</b>." 
    if kind == "redeem_completed":
        return f"Account <b>{esc(name)}</b> logged in successfully."
    if kind == "expired":
        action = "registration" if item.get("action") == "register" else "redeem"
        return f"Your OgSaver {action} code expired. Please create a new code."
    return esc(item.get("error_message") or "The operation could not be completed.")


_saver_notification_started = False


def saver_notification_loop():
    while True:
        try:
            for item in SAVER.get_notifications():
                user_id = int(item["telegram_user_id"])
                bot.send_message(user_id, saver_notification_text(item), reply_markup=saver_main_markup(user_id), disable_web_page_preview=True)
                SAVER.mark_notification(item["id"], item["kind"])
        except Exception:
            pass
        time.sleep(2)


def start_saver_notifications():
    global _saver_notification_started
    if _saver_notification_started or SAVER is None:
        return
    SAVER.initialize()
    threading.Thread(target=saver_notification_loop, name="OgSaverNotifications", daemon=True).start()
    _saver_notification_started = True


@bot.message_handler(commands=["start", "menu"])
def start_handler(message):
    if not is_admin(message.from_user.id):
        if getattr(message.chat, "type", "private") != "private":
            bot.reply_to(message, "Please use OgSaver in a private chat.")
            return
        show_saver_main(message.chat.id, message.from_user.id)
        return
    state_for(message.from_user.id).clear()
    bot.clear_step_handler_by_chat_id(message.chat.id)
    show_main(message)


@bot.message_handler(commands=["players"])
def players_handler(message):
    if not is_admin(message.from_user.id):
        if getattr(message.chat, "type", "private") == "private":
            show_saver_main(message.chat.id, message.from_user.id)
        return
    show_players(message, 0)


@bot.message_handler(commands=["delete"])
def delete_handler(message):
    if not is_admin(message.from_user.id):
        if getattr(message.chat, "type", "private") == "private":
            show_saver_main(message.chat.id, message.from_user.id)
        return
    show_delete(message, 0)


@bot.message_handler(commands=["register", "add"])
def saver_register_handler(message):
    if getattr(message.chat, "type", "private") != "private":
        bot.reply_to(message, "Please use OgSaver in a private chat.")
        return
    if SAVER is None:
        bot.reply_to(message, "OgSaver is unavailable.")
        return
    pending = SAVER.create_pending(message.from_user.id, "register", expiry_seconds=CODE_EXPIRY_SECONDS)
    if pending is None:
        bot.reply_to(message, "Could not create the registration code.")
        return
    bot.send_message(message.chat.id, saver_register_text(pending["code"]), reply_markup=saver_code_markup(message.from_user.id), disable_web_page_preview=True)


@bot.message_handler(commands=["accounts"])
def saver_accounts_handler(message):
    if getattr(message.chat, "type", "private") != "private":
        bot.reply_to(message, "Please use OgSaver in a private chat.")
        return
    if SAVER is None:
        bot.reply_to(message, "OgSaver is unavailable.")
        return
    markup, total, page = saver_accounts_markup(message.from_user.id, 0)
    bot.send_message(message.chat.id, saver_accounts_text(total), reply_markup=markup, disable_web_page_preview=True)


@bot.message_handler(commands=["cancel"])
def cancel_handler(message):
    bot.clear_step_handler_by_chat_id(message.chat.id)
    if not is_admin(message.from_user.id):
        if SAVER is not None:
            SAVER.cancel_pending(message.from_user.id)
        if getattr(message.chat, "type", "private") == "private":
            show_saver_main(message.chat.id, message.from_user.id)
        return
    bot.reply_to(message, "Ação cancelada.")


def handle_quantity(message, token, resource):
    if not is_admin(message.from_user.id):
        deny_message(message)
        return
    text = str(message.text or "").strip()
    if text.lower() in ("cancelar", "/cancel"):
        bot.send_message(message.chat.id, "Ação cancelada.", reply_markup=resources_markup())
        return
    quantity = parse_quantity(text)
    if quantity is None:
        sent = bot.send_message(message.chat.id, "Envie apenas um número inteiro. Exemplo: <code>1000</code>")
        bot.register_next_step_handler(sent, handle_quantity, token, resource)
        return
    if token == ALL_TOKEN:
        state_for(message.from_user.id)["token"] = ALL_TOKEN
        total = len(load_players())
        if not total:
            bot.send_message(message.chat.id, "Nenhuma conta encontrada na database.")
            return
        if resource in ("gems", "gold", "trophies"):
            result = apply_numeric_resource_all(resource, quantity)
            bot.send_message(
                message.chat.id,
                f"✅ <b>Recurso enviado para todos</b>\nRecurso: {resource_label(resource)}\nQuantidade por jogador: <b>{quantity}</b>\nJogadores atualizados: <b>{result['players']}/{total}</b>\nTotal aplicado: <b>{result['total_applied']}</b>\n\nCada jogador precisa entrar novamente no jogo para ver a alteração.",
                reply_markup=resources_markup(),
            )
            return
        if resource in ("brawlers", "skins") and quantity < 1:
            sent = bot.send_message(message.chat.id, "A quantidade precisa ser maior que zero.")
            bot.register_next_step_handler(sent, handle_quantity, ALL_TOKEN, resource)
            return
        if resource == "brawlers":
            result = unlock_brawlers_all(quantity=quantity)
            bot.send_message(
                message.chat.id,
                f"✅ <b>Brawlers enviados para todos</b>\nJogadores atualizados: <b>{result['players']}/{total}</b>\nDesbloqueios aplicados: <b>{result['grants']}</b>\n{format_names(result['added'], brawler_name)}",
                reply_markup=resources_markup(),
            )
            return
        if resource == "skins":
            result = unlock_skins_all(quantity=quantity)
            bot.send_message(
                message.chat.id,
                f"✅ <b>Skins enviadas para todos</b>\nJogadores atualizados: <b>{result['players']}/{total}</b>\nDesbloqueios aplicados: <b>{result['grants']}</b>\n{format_names(result['added'], skin_name)}",
                reply_markup=resources_markup(),
            )
            return
        return
    player = get_player(token)
    if player is None:
        bot.send_message(message.chat.id, "Essa conta não existe mais na database.")
        return
    state_for(message.from_user.id)["token"] = token
    if resource in ("gems", "gold", "trophies"):
        result = apply_numeric_resource(token, resource, quantity)
        if result is None:
            bot.send_message(message.chat.id, "Não consegui atualizar essa conta.")
            return
        name = esc(result["player"]["data"].get("name") or "Brawler")
        detail = f"Saldo: <b>{result['old']}</b> ➡️ <b>{result['new']}</b>"
        if resource == "trophies" and "brawler_id" in result:
            detail += (
                f"\n{brawler_name(result['brawler_id'])}: "
                f"<b>{result['brawler_old']}</b> ➡️ <b>{result['brawler_new']}</b> troféus"
            )
        bot.send_message(
            message.chat.id,
            f"✅ <b>Recurso enviado</b>\nJogador: <b>{name}</b>\nRecurso: {resource_label(resource)}\n{detail}\n\nO jogador precisa entrar novamente no jogo para ver a alteração.",
            reply_markup=resources_markup(),
        )
    elif resource == "brawlers":
        if quantity < 1:
            sent = bot.send_message(message.chat.id, "A quantidade de brawlers precisa ser maior que zero.")
            bot.register_next_step_handler(sent, handle_quantity, token, resource)
            return
        result = unlock_brawlers(token, quantity=quantity)
        added = result["added"] if result else []
        bot.send_message(
            message.chat.id,
            f"✅ <b>{len(added)} brawler(s) desbloqueado(s)</b>\n{format_names(added, brawler_name)}",
            reply_markup=resources_markup(),
        )
    elif resource == "skins":
        if quantity < 1:
            sent = bot.send_message(message.chat.id, "A quantidade de skins precisa ser maior que zero.")
            bot.register_next_step_handler(sent, handle_quantity, token, resource)
            return
        result = unlock_skins(token, quantity=quantity)
        added = result["added"] if result else []
        bot.send_message(
            message.chat.id,
            f"✅ <b>{len(added)} skin(s) desbloqueada(s)</b>\n{format_names(added, skin_name)}",
            reply_markup=resources_markup(),
        )


@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    if (call.data or "").startswith("og:"):
        saver_callback(call)
        return
    if not is_admin(call.from_user.id):
        bot.answer_callback_query(call.id)
        if getattr(call.message.chat, "type", "private") == "private":
            show_saver_main(call.message.chat.id, call.from_user.id, call.message.message_id)
        return
    data = call.data or ""
    user_id = call.from_user.id
    state = state_for(user_id)
    try:
        if data == "menu":
            bot.answer_callback_query(call.id)
            state.clear()
            bot.clear_step_handler_by_chat_id(call.message.chat.id)
            show_main(call)
            return
        if data == "noop":
            bot.answer_callback_query(call.id, "Esse item já está desbloqueado.")
            return
        if data.startswith("pl:"):
            bot.answer_callback_query(call.id)
            show_players(call, safe_int(data.split(":")[1]))
            return
        if data.startswith("dl:"):
            bot.answer_callback_query(call.id)
            show_delete(call, safe_int(data.split(":")[1]))
            return
        if data.startswith("bn:"):
            bot.answer_callback_query(call.id)
            show_ban(call, safe_int(data.split(":")[1]))
            return
        if data.startswith("bb:"):
            parts = data.split(":")
            player = find_player_by_key(parts[1])
            if player is None:
                bot.answer_callback_query(call.id, "Conta não encontrada.", show_alert=True)
                return
            page = safe_int(parts[2]) if len(parts) > 2 else 0
            result = ban_player_ip(player["token"])
            ip = result.get("ip") if result else ""
            bot.answer_callback_query(call.id, "Jogador banido.")
            ban_lines = []
            if result and result.get("banned_ip"):
                ban_lines.append(f"IP salvo em <code>banned_ip.json</code>: <code>{esc(ip)}</code>")
            elif ip:
                ban_lines.append(f"Falha ao salvar o IP <code>{esc(ip)}</code> em <code>banned_ip.json</code>.")
            else:
                ban_lines.append("Nenhum IP estava salvo nessa conta.")
            ban_lines.append("Nome da conta alterado para <b>Account banned</b>.")
            if result and result.get("ban_error"):
                ban_lines.append(f"Erro ao gravar o arquivo de ban: <code>{esc(result.get('ban_error'))}</code>")
            if result and result.get("reason"):
                ban_lines.append(f"Razão: {esc(result.get('reason'))}")
            ban_text = "\n".join(ban_lines)
            markup, total, page = ban_markup(page)
            show(
                call,
                f"🚫 <b>Jogador banido</b>\nJogador: <b>{esc(result.get('name') if result else '')}</b>\nID: <code>#{esc(result.get('low_id') if result else '')}</code>\n{ban_text}\n\nRestam {total} conta(s).",
                markup,
            )
            return
        if data.startswith("un:"):
            bot.answer_callback_query(call.id)
            show_unban(call, safe_int(data.split(":")[1]))
            return
        if data.startswith("uu:"):
            parts = data.split(":")
            kind = parts[1] if len(parts) > 1 else ""
            key = parts[2] if len(parts) > 2 else ""
            page = safe_int(parts[3]) if len(parts) > 3 else 0
            result = unban_entry(kind, key)
            bot.answer_callback_query(call.id, "Ban removido.")
            lines = []
            if result.get("removed_ip"):
                lines.append(f"IP removido de <code>banned_ip.json</code>: <code>{esc(result.get('ip') or key)}</code>")
            if result.get("removed_acc"):
                lines.append(f"Conta removida de <code>banned_acc.json</code>: <code>#{esc(result.get('low_id') or key)}</code>")
            if not lines:
                lines.append("Esse ban já não estava mais nos arquivos.")
            if result.get("restored_name"):
                lines.append(f"Nome restaurado para <b>{esc(result.get('restored_name'))}</b>.")
            markup, total, page = unban_markup(page)
            show(call, "♻️ <b>Desban</b>\n" + "\n".join(lines) + f"\n\nRestam {total} ban(s).", markup)
            return
        if data.startswith("pa:"):
            target = all_players_target()
            if not target["data"].get("players_count"):
                bot.answer_callback_query(call.id, "Nenhuma conta encontrada.", show_alert=True)
                return
            state["token"] = ALL_TOKEN
            state["players_page"] = safe_int(data.split(":")[1]) if ":" in data else 0
            bot.answer_callback_query(call.id)
            show_player(call, target, state["players_page"])
            return
        if data.startswith("ps:"):
            parts = data.split(":")
            player = find_player_by_key(parts[1])
            if player is None:
                bot.answer_callback_query(call.id, "Conta não encontrada.", show_alert=True)
                return
            state["token"] = player["token"]
            state["players_page"] = safe_int(parts[2]) if len(parts) > 2 else 0
            bot.answer_callback_query(call.id)
            show_player(call, player, state["players_page"])
            return
        if data.startswith("dd:"):
            parts = data.split(":")
            player = find_player_by_key(parts[1])
            if player is None:
                bot.answer_callback_query(call.id, "Conta não encontrada.", show_alert=True)
                return
            page = safe_int(parts[2]) if len(parts) > 2 else 0
            result = delete_player_and_ban(player["token"])
            if state.get("token") == player["token"]:
                state.pop("token", None)
            ip = result.get("ip") if result else ""
            bot.answer_callback_query(call.id, "Conta excluída.")
            ban_lines = []
            if result and result.get("banned_ip"):
                ban_lines.append(f"IP salvo em <code>banned_ip.json</code>: <code>{esc(ip)}</code>")
            elif ip:
                ban_lines.append(f"Falha ao salvar o IP <code>{esc(ip)}</code> em <code>banned_ip.json</code>.")
            else:
                ban_lines.append("Nenhum IP estava salvo nessa conta.")
            if result and result.get("banned_acc"):
                ban_lines.append("Conta salva em <code>banned_acc.json</code>.")
            if result and result.get("ban_error"):
                ban_lines.append(f"Erro ao gravar os arquivos de ban: <code>{esc(result.get('ban_error'))}</code>")
            if result and result.get("reason"):
                ban_lines.append(f"Razão: {esc(result.get('reason'))}")
            ban_text = "\n".join(ban_lines)
            markup, total, page = delete_markup(page)
            show(
                call,
                f"✅ <b>Conta excluída</b>\nJogador: <b>{esc(result.get('name') if result else '')}</b>\nID: <code>#{esc(result.get('low_id') if result else '')}</code>\n{ban_text}\n\nRestam {total} conta(s).",
                markup,
            )
            return

        player = current_player(user_id)
        if data == "backplayer":
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            bot.answer_callback_query(call.id)
            show_player(call, player, safe_int(state.get("players_page")))
            return
        if data == "resources":
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            bot.answer_callback_query(call.id)
            show_resources(call, player)
            return
        if data.startswith("qty:"):
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            resource = data.split(":", 1)[1]
            bot.answer_callback_query(call.id)
            sent = bot.send_message(
                call.message.chat.id,
                f"Digite a quantidade de {resource_label(resource)} para enviar para <b>{esc(player['data'].get('name') or 'Brawler')}</b>.\n\nExemplo: <code>1000</code>\nPara cancelar, envie <code>cancelar</code>.",
            )
            bot.register_next_step_handler(sent, handle_quantity, player["token"], resource)
            return
        if data.startswith("brmenu:"):
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            markup, page = brawlers_markup(player, safe_int(data.split(":")[1]))
            bot.answer_callback_query(call.id)
            show(call, "🥊 <b>Brawlers</b>\nToque em um brawler bloqueado para desbloquear, ou use o botão de quantidade.", markup)
            return
        if data.startswith("ub:"):
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            parts = data.split(":")
            brawler_id = safe_int(parts[1])
            page = safe_int(parts[2]) if len(parts) > 2 else 0
            if player["token"] == ALL_TOKEN:
                result = unlock_brawlers_all(brawler_ids=[brawler_id])
                added = result["added"] if result else []
                answer = f"{brawler_name(brawler_id)} desbloqueado para {result.get('players', 0)} jogador(es)." if added else "Todos já tinham esse brawler."
            else:
                result = unlock_brawlers(player["token"], brawler_ids=[brawler_id])
                added = result["added"] if result else []
                answer = f"{brawler_name(brawler_id)} desbloqueado." if added else "Esse brawler já estava desbloqueado."
            bot.answer_callback_query(call.id, answer)
            updated = refresh_target(player)
            markup, page = brawlers_markup(updated, page)
            show(call, "🥊 <b>Brawlers</b>\nToque em um brawler bloqueado para desbloquear, ou use o botão de quantidade.", markup)
            return
        if data == "uball":
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            if player["token"] == ALL_TOKEN:
                result = unlock_brawlers_all(quantity=len(CHARACTERS))
                bot.answer_callback_query(call.id, f"{result.get('grants', 0)} desbloqueio(s) para {result.get('players', 0)} jogador(es).")
            else:
                result = unlock_brawlers(player["token"], quantity=len(CHARACTERS))
                added = result["added"] if result else []
                bot.answer_callback_query(call.id, f"{len(added)} brawler(s) desbloqueado(s).")
            updated = refresh_target(player)
            markup, page = brawlers_markup(updated, 0)
            show(call, "🥊 <b>Brawlers</b>", markup)
            return
        if data.startswith("skmenu:"):
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            markup, page = skin_brawlers_markup(player, safe_int(data.split(":")[1]))
            bot.answer_callback_query(call.id)
            show(call, "👕 <b>Skins</b>\nEscolha o brawler para ver as skins, ou use o botão de quantidade.", markup)
            return
        if data.startswith("sb:"):
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            parts = data.split(":")
            brawler_id = safe_int(parts[1])
            page = safe_int(parts[2]) if len(parts) > 2 else 0
            parent_page = safe_int(parts[3]) if len(parts) > 3 else 0
            markup, page = skins_markup(player, brawler_id, page, parent_page)
            bot.answer_callback_query(call.id)
            show(call, f"👕 <b>Skins de {esc(brawler_name(brawler_id))}</b>", markup)
            return
        if data.startswith("us:"):
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            parts = data.split(":")
            skin_id = safe_int(parts[1])
            brawler_id = safe_int(parts[2]) if len(parts) > 2 else SKINS.get(skin_id, {}).get("brawler_id", 0)
            page = safe_int(parts[3]) if len(parts) > 3 else 0
            parent_page = safe_int(parts[4]) if len(parts) > 4 else 0
            if player["token"] == ALL_TOKEN:
                result = unlock_skins_all(skin_ids=[skin_id])
                added = result["added"] if result else []
                answer = f"{skin_name(skin_id)} desbloqueada para {result.get('players', 0)} jogador(es)." if added else "Todos já tinham essa skin."
            else:
                result = unlock_skins(player["token"], skin_ids=[skin_id])
                added = result["added"] if result else []
                answer = f"{skin_name(skin_id)} desbloqueada." if added else "Essa skin já estava desbloqueada."
            bot.answer_callback_query(call.id, answer)
            updated = refresh_target(player)
            markup, page = skins_markup(updated, brawler_id, page, parent_page)
            show(call, f"👕 <b>Skins de {esc(brawler_name(brawler_id))}</b>", markup)
            return
        if data == "usall":
            if player is None:
                bot.answer_callback_query(call.id, "Selecione um jogador primeiro.", show_alert=True)
                return
            all_skins = [skin_id for skin_id in sorted(SKINS) if skin_id not in DEFAULT_SKINS]
            if player["token"] == ALL_TOKEN:
                result = unlock_skins_all(skin_ids=all_skins)
                bot.answer_callback_query(call.id, f"{result.get('grants', 0)} desbloqueio(s) para {result.get('players', 0)} jogador(es).")
            else:
                result = unlock_skins(player["token"], skin_ids=all_skins)
                added = result["added"] if result else []
                bot.answer_callback_query(call.id, f"{len(added)} skin(s) desbloqueada(s).")
            updated = refresh_target(player)
            markup, page = skin_brawlers_markup(updated, 0)
            show(call, "👕 <b>Skins</b>", markup)
            return
        bot.answer_callback_query(call.id, "Opção não reconhecida.")
    except Exception as error:
        try:
            bot.answer_callback_query(call.id, "Ocorreu um erro.", show_alert=True)
        except Exception:
            pass
        bot.send_message(call.message.chat.id, f"❌ Erro: <code>{esc(error)}</code>")


@bot.message_handler(func=lambda message: True, content_types=["text"])
def fallback_handler(message):
    if not is_admin(message.from_user.id):
        if getattr(message.chat, "type", "private") == "private":
            show_saver_main(message.chat.id, message.from_user.id)
        return
    show_main(message)


def register_bot_commands():
    public_commands = [
        types.BotCommand("start", "Open the menu"),
        types.BotCommand("register", "Register a game account"),
        types.BotCommand("accounts", "Show my saved accounts"),
        types.BotCommand("add", "Add another game account"),
        types.BotCommand("cancel", "Cancel the current action"),
    ]
    admin_commands = [
        types.BotCommand("start", "Abrir o painel"),
        types.BotCommand("players", "Listar jogadores"),
        types.BotCommand("delete", "Excluir conta e banir IP"),
        types.BotCommand("register", "Register a game account"),
        types.BotCommand("accounts", "Show my saved accounts"),
        types.BotCommand("add", "Add another game account"),
        types.BotCommand("cancel", "Cancelar a ação atual"),
    ]
    bot.set_my_commands(public_commands)
    scope_type = getattr(types, "BotCommandScopeChat", None)
    if scope_type is not None:
        for admin_id in ADMIN_IDS:
            try:
                bot.set_my_commands(admin_commands, scope=scope_type(admin_id))
            except Exception:
                pass


def main():
    if not BOT_TOKEN or BOT_TOKEN == "TOKEN_NAO_CONFIGURADO" or BOT_TOKEN == "COLOQUE_SEU_TOKEN_AQUI":
        raise SystemExit("Configure BOT_TOKEN no arquivo AdminBot/config.json ou na variavel de ambiente BOT_TOKEN.")
    if not DATABASE_PATH.exists():
        raise SystemExit(f"Database nao encontrada: {DATABASE_PATH}")
    connection = db_connect()
    connection.commit()
    connection.close()
    start_saver_notifications()
    register_bot_commands()
    bot.infinity_polling(timeout=60, long_polling_timeout=60)


if __name__ == "__main__":
    main()
